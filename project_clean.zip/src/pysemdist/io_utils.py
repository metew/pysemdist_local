from __future__ import annotations
import json
from pathlib import Path
from typing import Iterable
import pandas as pd

REQUIRED_FIELDS = {"id", "text"}


def load_petitions(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)

    if path.suffix.lower() in {".jsonl", ".jl"}:
        rows = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
        df = pd.DataFrame(rows)

    elif path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "data" in data:
            data = data["data"]
        df = pd.DataFrame(data)

    else:
        raise ValueError("Unsupported file format. Use .json or .jsonl")

    # Check for required fields
    missing = REQUIRED_FIELDS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required fields: {missing}")

    # Ensure optional columns exist
    for col in ["category", "locale"]:
        if col not in df.columns:
            df[col] = None

    return df


def ensure_dirs(paths: Iterable[Path]) -> None:
    for p in paths:
        p.parent.mkdir(parents=True, exist_ok=True)


def to_parquet_append(df: pd.DataFrame, path: Path) -> None:
    ensure_dirs([path])
    if path.exists():
        existing = pd.read_parquet(path)
        pd.concat([existing, df], ignore_index=True).to_parquet(path, index=False)
    else:
        df.to_parquet(path, index=False)
